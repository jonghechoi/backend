package java_code.java_11day;

public class ZooKeeper {
	
	public void checkAnimal(String name, int num) {
		AnimalVo[]
		if(name.equals(""))
	}
}
